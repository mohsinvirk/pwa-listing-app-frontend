/*
Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
See license file for more information
Contact developers at mr.dinesh.bhosale@gmail.com
*/
var dirName="capfr";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.wait="Please wait , canceling all pending friend requests.";
messages.confirm_to_cancel="Are you sure you want to cancel all pending friend requests ?";
messages.all_cancelled="All pending friend requests are canceled.";
