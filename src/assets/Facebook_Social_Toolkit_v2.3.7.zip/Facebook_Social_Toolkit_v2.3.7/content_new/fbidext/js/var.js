/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var toolTitle = "Facebook ID Extractor";
var dirName="fbidext";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.nothing_to_extract="Nothing to extract. please enter another URL.";
messages.invalid_url="URL entered by you doesn't belong to Facebook.com.";
messages.enter_valid_url="Please Enter a valid URL.";
messages.please_wait='Please wait, extracting IDs.';
messages.url_is_tampered="URL is tampered.";
