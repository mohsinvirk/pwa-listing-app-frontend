/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var toolTitle = "Extract User Likes";
var toolTitle = "Extract User Likes";
var dirName="egids";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.not_complete="Group extraction is not complete. Please wait until Group extraction is completed. Also make sure that you are a member of more than one Facebook group.";
messages.not_a_member="Are you sure you are member of Facebook groups ?";
messages.extracted="Group IDs are extracted.";
