/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var dirName="uaffao";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.confirm_msg="All friends will be removed. Do you really want to do this ? ";
messages.confirm_msg_1="Are you sure you want to remove all friends from your friend list once it is done it can not be undone.";
messages.confirm_msg_2="Again confirm that you want to remove all friends.";
messages.not_complete="Friend list extraction is not complete. Please wait until friend list extraction is complete.";
messages.invalid_answer="Invalid answer.";
messages.success="All friends are removed.";
