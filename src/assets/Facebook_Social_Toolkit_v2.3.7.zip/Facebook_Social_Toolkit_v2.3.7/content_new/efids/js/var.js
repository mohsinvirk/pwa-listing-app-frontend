/*
Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
See license file for more information
Contact developers at mr.dinesh.bhosale@gmail.com
*/
var toolTitle = "Extract Friend IDs";
var dirName="efids";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.not_complete="Friend list extraction is not complete. Please wait until friend list extraction is complete.";
messages.id_not_found="No friend IDs found.";
messages.extracted="Friend IDs are extracted.";
