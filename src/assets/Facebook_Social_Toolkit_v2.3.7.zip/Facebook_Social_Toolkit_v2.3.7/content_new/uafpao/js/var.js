/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var dirName="uafpao";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.incomplete="Page extraction is not complete. Please wait until Page extraction is complete. Also make sure that you have liked at least one Facebook page.";
messages.cant_find="We can't find Facebook pages to unlike.";
messages.confirm_msg="Please confirm that you want to unlike all pages. Once you have unliked all pages it can not be reversed.";
messages.no_pages_to_unlike="You have no pages to unlike.";
messages.success="All pages are successfully unliked.";
