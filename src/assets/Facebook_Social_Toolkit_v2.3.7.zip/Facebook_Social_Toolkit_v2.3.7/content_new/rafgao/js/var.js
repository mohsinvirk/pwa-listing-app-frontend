/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var dirName="rafgao";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var toolTitle="Remove All Groups";
var messages={};
messages.extraction_incomplete="Group extraction is not complete. Please wait until group extraction is complete.";
messages.make_sure="Please make sure you are member of at least one Facebook group.";
messages.are_you_sure="Are you sure you are member of Facebook groups?";
messages.all_removed="All groups removed successfully";
messages.confirm_msg="Are you sure you want to leave all groups. Once it is done it can not be undone.";
messages.info_msg="If you are a member of too many groups then it will take a while time to leave all groups.";