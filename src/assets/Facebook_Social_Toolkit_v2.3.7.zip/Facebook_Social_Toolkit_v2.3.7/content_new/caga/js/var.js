/*
Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
See license file for more information
Contact developers at mr.dinesh.bhosale@gmail.com
*/
var dirName="caga";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.confirm="Claim as group admin makes you the admin of the Facebook groups that have no admin or Facebook groups with deactivated Facebook admin accounts. Your browser may freeze during the process. Do you want to continue ?";
messages.extraction_error="Group extraction is not complete. Please wait until group extraction is complete. Also make sure that you are a member of at least one Facebook group.";
messages.not_complete="Group extraction is not complete. Please wait until group extraction is complete. Also make sure that you are a member of at least one Facebook group.";
messages.not_a_member="Are you sure you are member of at least one Facebook group ?";
messages.started="Claim admin script started successfully. Please wait until it executes completely.";
messages.executed="Claim admin script executed successfully.";
messages.wait="Please wait while claim admin script is executing.";
