/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var toolTitle = "Extract User Likes";
var dirName = "eulikes";
var targetFrameId = 'fstFrameDiv';
var targetDivId = 'fstParentDiv';
var messages={};
messages.please_wait="Please wait until page likes extraction process is completed.";
messages.unable_to_detect= "Unable to detect page likes.";
messages.likes_are_extracted="Page likes are extracted.";
messages.extracted="User likes are extracted.";
