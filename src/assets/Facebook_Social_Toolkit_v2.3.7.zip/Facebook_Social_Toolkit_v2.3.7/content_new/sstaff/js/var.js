/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var toolTitle = "Send Stickers To All Facebook Friends";
var dirName="sstaff";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.successfully_sent="Messages sent successfully.";
messages.please_wait="Friend list extraction is not complete. Please wait until friend list extraction is complete.";
messages.cant_be_equal="Starting number and ending number can't be equal.";
messages.ending_number_invalid="Ending number is invalid.";
messages.starting_invalid="Starting number is invalid.";
messages.invalid_delay="Invalid delay time.";
messages.invalid_sticker="Invalid sticker ID.";
