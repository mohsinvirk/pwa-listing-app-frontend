/*
Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
See license file for more information
Contact developers at mr.dinesh.bhosale@gmail.com
*/
var dirName="clicklike";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var unlikeClass='UFILinkBright';
var messages={};
messages.all_clicked="All like buttons are clicked.";
