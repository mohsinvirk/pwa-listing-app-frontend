/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var dirName="sbwish";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var toolTitle="Remove All Groups";
var messages={};
messages.please_wait="Please wait, sending birthday wishes.";
messages.unsafe_error="The content you're trying to share includes a link that our security systems detected to be unsafe.";
messages.emptyBirthdhdaymessageError="Blank birthDay message.";
messages.noBirthdayFound="Unable to find friends whose birthDay is today.";
